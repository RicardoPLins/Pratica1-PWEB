class Disciplina{
    constructor(codigo, nome) {
        this.codigo = codigo;
        this._nome = nome;
    }
    get nome(){
        return this._nome;
    }
    set nome(novoNome){
        this._nome = novoNome;
    }
}