class DisciplinaServico {
    constructor() {
        this.repositorio = new DisciplinaRepositorio();
    }

    inserir(codigo, nome) {
        const disciplina = new Disciplina(codigo, nome);
        return this.repositorio.inserir(disciplina);
        // if (disciplina.codigo !== codigo) {
        //     return this.repositorio.inserir(disciplina);
        //     console.log("o inserir no serviço pega");
        // }
        // return undefined;

    }

    remover(codigo) {
        this.repositorio.remover(codigo);
    }

    listar() {
        return this.repositorio.listar();
    }

    buscarPorNome(nome) {
        return this.repositorio.buscarPorNome(nome);
    }
    // inserirAlunonaDisciplina(nomeAluno, idadeAluno){
    //     const aluno = new Aluno(nomeAluno, idadeAluno);
    //     if(aluno.idade >=18){
    //         return this.repositorio.inserirAlunonaDisciplina(aluno);
    //     }
    //     return undefined;
    //
    // }
}
