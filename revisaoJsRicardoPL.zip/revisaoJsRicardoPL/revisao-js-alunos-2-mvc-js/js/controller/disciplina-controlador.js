class DisciplinaControlador {
    constructor() {
        this.diciplinaServico = new DisciplinaServico();
    }

    inserir() {
        const codDisciplina = Number(document.querySelector("#codigoDisc").value);
        const nomeDisciplina = document.querySelector("#nomeDisc").value;
        const disciplina = this.diciplinaServico.inserir(codDisciplina, nomeDisciplina);

        if (disciplina) {
            this.mostrarDisciplinaNoHTML(codDisciplina, nomeDisciplina);
            alert('Disciplina inserido com sucesso!');
        } else {
            alert('Disciplina não foi inserida!');
        }
    }


    mostrarDisciplinaNoHTML(codigo, nome) {
        const elementoP = document.createElement("p");
        elementoP.textContent = `${codigo} - ${nome}`;

        const elementoBotaoApagar = document.createElement("button");
        elementoBotaoApagar.textContent = "X";

        elementoBotaoApagar.addEventListener('click', (event) => {
                this.removerDisciplinaDaLista(codigo);
                event.target.parentElement.remove();
            }
        );
        elementoP.appendChild(elementoBotaoApagar);
        document.body.appendChild(elementoP);
    }

    removerDisciplinaDaLista(codigo) {
        this.diciplinaServico.remover(codigo);
    }

}

//
//
//
// for (let aluno of alunos) {
//     // colocar no html nome - idade
//     mostrarAlunoNoHTML(aluno.nome, aluno.idade);
// }
//
// function inserirAluno() {
// }
//
//

