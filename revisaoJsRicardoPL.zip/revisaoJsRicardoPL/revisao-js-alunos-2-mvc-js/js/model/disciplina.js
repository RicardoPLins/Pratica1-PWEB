
class Disciplina{
    constructor(codigo, nome) {
        this.codigo = codigo;
        this._nome = nome;
        //this._alunos = [];
    }
    get nome(){
        return this._nome;
    }
    set nome(novonome){
        this._nome = novonome;
    }
    // get alunos(){
    //     return this._alunos
    // }
    // set alunos(aluno){
    //     this._alunos.push(aluno);
    // }
}