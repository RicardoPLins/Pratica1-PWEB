const alunoControlador = new AlunoControlador();
const disciplinaControlador = new DisciplinaControlador();
